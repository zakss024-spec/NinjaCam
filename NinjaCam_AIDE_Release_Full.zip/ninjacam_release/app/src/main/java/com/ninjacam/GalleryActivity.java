package com.ninjacam;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class GalleryActivity extends Activity {
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xFF101014);getWindow().setNavigationBarColor(0xFF101014);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xFF101014);
        TextView head=new TextView(this);head.setText("  NinjaCam Gallery");head.setTextColor(0xFFFFFFFF);head.setTextSize(21);head.setGravity(Gravity.CENTER_VERTICAL);root.addView(head,new LinearLayout.LayoutParams(-1,dp(64)));
        android.widget.ScrollView sv=new android.widget.ScrollView(this);LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);sv.addView(grid);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        load(grid);
    }
    private void load(LinearLayout grid){ArrayList<Uri> items=new ArrayList<>();String[] p={MediaStore.Images.Media._ID,MediaStore.Images.Media.DATE_ADDED};String sel=MediaStore.Images.Media.RELATIVE_PATH+"=?";String[] args={"Pictures/NinjaCam/"};Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,p,sel,args,MediaStore.Images.Media.DATE_ADDED+" DESC");if(c!=null){while(c.moveToNext()){long id=c.getLong(0);items.add(Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,""+id));}c.close();}
        if(items.isEmpty()){TextView empty=new TextView(this);empty.setText("Belum ada foto NinjaCam.\nAmbil foto dulu dari kamera.");empty.setTextColor(0xFFCCCCCC);empty.setTextSize(16);empty.setGravity(Gravity.CENTER);grid.addView(empty,new LinearLayout.LayoutParams(-1,dp(220)));return;}
        LinearLayout row=null;for(int i=0;i<items.size();i++){if(i%3==0){row=new LinearLayout(this);row.setGravity(Gravity.CENTER);grid.addView(row,new LinearLayout.LayoutParams(-1,dp(126)));}final Uri u=items.get(i);ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);try{Bitmap bm=MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),Long.parseLong(u.getLastPathSegment()),MediaStore.Images.Thumbnails.MINI_KIND,null);iv.setImageBitmap(bm);}catch(Exception e){iv.setBackgroundColor(0xFF303038);}iv.setOnClickListener(v->{try{Intent x=new Intent(Intent.ACTION_VIEW,u);x.setDataAndType(u,"image/jpeg");startActivity(x);}catch(Exception e){Toast.makeText(this,"Tidak ada aplikasi galeri",Toast.LENGTH_SHORT).show();}});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(118),1);lp.setMargins(dp(3),dp(3),dp(3),dp(3));row.addView(iv,lp);}
    }
}
