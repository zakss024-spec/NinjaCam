package com.ninjacam;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.MeteringPointFactory;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 10;
    private static final int REQ_AUDIO = 11;

    private FrameLayout root;
    private PreviewView preview;
    private Camera camera;
    private ProcessCameraProvider provider;
    private ImageCapture imageCapture;
    private VideoCapture<Recorder> videoCapture;
    private Recording recording;
    private boolean front = false;
    private boolean recordingNow = false;
    private boolean gridOn = false;
    private boolean hdrOn = false;
    private int timerSeconds = 0;
    private int flashMode = ImageCapture.FLASH_MODE_AUTO;
    private float minZoom = 1f, maxZoom = 1f, zoom = 1f;
    private String mode = "PHOTO";
    private TextView status, zoomText;
    private SeekBar zoomSeek;
    private LinearLayout quickZoom;
    private Button shutter;
    private ScaleGestureDetector scaleDetector;
    private View gridView;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindow();
        buildCameraUi();
        showIntro();
    }

    private void requestWindow() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
    }

    private void buildCameraUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        preview = new PreviewView(this);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(preview, new FrameLayout.LayoutParams(-1, -1));

        gridView = new View(this) {
            @Override protected void onDraw(android.graphics.Canvas c) {
                super.onDraw(c);
                android.graphics.Paint p = new android.graphics.Paint();
                p.setColor(0x66FFFFFF); p.setStrokeWidth(1f);
                float w = getWidth(), h = getHeight();
                c.drawLine(w/3, 0, w/3, h, p); c.drawLine(w*2/3, 0, w*2/3, h, p);
                c.drawLine(0, h/3, w, h/3, p); c.drawLine(0, h*2/3, w, h*2/3, p);
            }
        };
        gridView.setVisibility(View.GONE);
        root.addView(gridView, new FrameLayout.LayoutParams(-1, -1));

        addTop(); addZoom(); addBottom(); setupGestures();
        setContentView(root);
    }

    private void showIntro() {
        final FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.BLACK);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        final android.view.SurfaceView video = new android.view.SurfaceView(this);
        overlay.addView(video, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(this);
        shade.setBackground(new GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00000000,0x22000000,0xB8000000}));
        overlay.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL); info.setGravity(Gravity.CENTER);
        info.addView(introText("NinjaCamera", 28, true));
        info.addView(introText("Developer:Zackss", 13, false));
        info.addView(introText("Fahiraa My Loveee", 12, false));
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        ip.topMargin = (int)(getResources().getDisplayMetrics().heightPixels * 0.62f);
        overlay.addView(info, ip);

        final TextView progressText = introText("0%", 12, false);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, dp(40), Gravity.BOTTOM);
        pp.bottomMargin = dp(42); overlay.addView(progressText, pp);

        final View barBg = new View(this); barBg.setBackground(round(0x66333333, dp(8), 0));
        final View bar = new View(this); bar.setBackground(round(Color.WHITE, dp(8), 0)); bar.setScaleX(0f); bar.setPivotX(0f);
        FrameLayout barWrap = new FrameLayout(this); barWrap.addView(bar, new FrameLayout.LayoutParams(dp(280), dp(5)));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(280), dp(5), Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        bp.bottomMargin = dp(26); overlay.addView(barBg, bp); overlay.addView(barWrap, bp);

        final MediaPlayer[] player = new MediaPlayer[1];
        final boolean[] started = new boolean[]{false};
        video.getHolder().addCallback(new android.view.SurfaceHolder.Callback() {
            @Override public void surfaceCreated(android.view.SurfaceHolder holder) {
                if (started[0]) return;
                started[0] = true;
                try {
                    android.content.res.AssetFileDescriptor afd = getAssets().openFd("ninja_intro.mp4");
                    MediaPlayer mp = new MediaPlayer();
                    player[0] = mp;
                    mp.setDisplay(holder);
                    mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                    afd.close();
                    mp.setOnPreparedListener(m -> {
                        m.setLooping(false); m.start();
                        final int duration = Math.max(1, m.getDuration());
                        handler.post(new Runnable() { public void run() {
                            if (overlay.getParent() == null || player[0] == null) return;
                            int pos = m.getCurrentPosition(); float f = Math.min(1f, pos/(float)duration);
                            bar.setScaleX(f); progressText.setText(((int)(f*100)) + "%");
                            if (m.isPlaying()) handler.postDelayed(this, 50);
                        }});
                    });
                    mp.setOnCompletionListener(m -> finishIntro(overlay, mp));
                    mp.setOnErrorListener((m, what, extra) -> { finishIntro(overlay, mp); return true; });
                    mp.prepareAsync();
                } catch (Exception e) {
                    finishIntro(overlay, player[0]);
                }
            }
            @Override public void surfaceChanged(android.view.SurfaceHolder holder, int format, int width, int height) {}
            @Override public void surfaceDestroyed(android.view.SurfaceHolder holder) {}
        });
    }

    private TextView introText(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setGravity(Gravity.CENTER);
        t.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); t.setShadowLayer(8,0,2,Color.BLACK); return t;
    }

    private void finishIntro(FrameLayout overlay, MediaPlayer mp) {
        if (mp != null) try { if (mp.isPlaying()) mp.stop(); mp.release(); } catch (Exception ignored) {}
        if (overlay.getParent() != null) overlay.animate().alpha(0f).setDuration(450).withEndAction(() -> {
            root.removeView(overlay); requestCamera();
        }).start();
    }

    private void requestCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera();
        else ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
    }

    @Override public void onRequestPermissionsResult(int r, @NonNull String[] p, @NonNull int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == REQ_CAMERA && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) startCamera();
        else if (r == REQ_AUDIO) startVideoWithAudio(false);
    }

    private void addTop() {
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(10),dp(8),dp(10),dp(8));
        status = new TextView(this); status.setText("NINJACAM • PHOTO"); status.setTextColor(Color.WHITE); status.setTextSize(12); status.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(status, new LinearLayout.LayoutParams(0,dp(44),1));
        Button flash = glass("⚡ AUTO"); flash.setOnClickListener(v -> {cycleFlash(); flash.setText(flashLabel());});
        Button hdr = glass("HDR"); hdr.setOnClickListener(v -> {hdrOn=!hdrOn; hdr.setText(hdrOn?"HDR ON":"HDR");});
        Button timer = glass("◷"); timer.setOnClickListener(v -> {timerSeconds=timerSeconds==0?3:(timerSeconds==3?5:0); timer.setText(timerSeconds==0?"◷":"◷ "+timerSeconds+"s");});
        Button settings = glass("⚙"); settings.setOnClickListener(v -> settings());
        bar.addView(flash); bar.addView(hdr); bar.addView(timer); bar.addView(settings);
        root.addView(bar, new FrameLayout.LayoutParams(-1,dp(62),Gravity.TOP));
    }

    private void addZoom() {
        zoomText = new TextView(this); zoomText.setText("1.0×"); zoomText.setTextColor(Color.WHITE); zoomText.setTextSize(16); zoomText.setGravity(Gravity.CENTER); zoomText.setShadowLayer(7,0,1,Color.BLACK);
        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(dp(90),dp(44),Gravity.CENTER_HORIZONTAL); zp.topMargin=dp(285); root.addView(zoomText,zp);
        quickZoom = new LinearLayout(this); quickZoom.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams qp=new FrameLayout.LayoutParams(-2,dp(44),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); qp.bottomMargin=dp(220); root.addView(quickZoom,qp);
        zoomSeek=new SeekBar(this); zoomSeek.setMax(1000); zoomSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){if(u)setZoom(minZoom+(maxZoom-minZoom)*p/1000f);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(270),dp(44),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); sp.bottomMargin=dp(172); root.addView(zoomSeek,sp);
    }

    private void addBottom() {
        LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setGravity(Gravity.CENTER); panel.setPadding(dp(10),dp(8),dp(10),dp(10)); panel.setBackground(round(0xAA181818,dp(28),0x66FFFFFF));
        LinearLayout modes=new LinearLayout(this); modes.setGravity(Gravity.CENTER);
        String[] ms={"NIGHT","PHOTO","VIDEO","ASTRO","PRO","LIVE"}; for(String m:ms){Button b=glass(m);b.setTextSize(10);b.setOnClickListener(v->selectMode(m));modes.addView(b);}
        panel.addView(modes,new LinearLayout.LayoutParams(-1,dp(42)));
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER_VERTICAL);
        Button gal=glass("▣");gal.setOnClickListener(v->startActivity(new Intent(this,GalleryActivity.class)));
        shutter=new Button(this);shutter.setText("●");shutter.setTextSize(28);shutter.setTextColor(Color.BLACK);shutter.setBackground(round(Color.WHITE,dp(90),0x88FFFFFF));shutter.setOnClickListener(v->shutter());
        Button sw=glass("↻");sw.setOnClickListener(v->switchCamera());
        controls.addView(gal,new LinearLayout.LayoutParams(dp(70),dp(64)));controls.addView(shutter,new LinearLayout.LayoutParams(dp(82),dp(82)));controls.addView(sw,new LinearLayout.LayoutParams(dp(70),dp(64)));
        panel.addView(controls);
        FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,dp(185),Gravity.BOTTOM);root.addView(panel,pp);
    }

    private void setupGestures(){
        scaleDetector=new ScaleGestureDetector(this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector d){setZoom(zoom*d.getScaleFactor());return true;}});
        preview.setOnTouchListener((v,e)->{scaleDetector.onTouchEvent(e);if(e.getAction()==MotionEvent.ACTION_UP)focus(e.getX(),e.getY());return true;});
    }

    private void startCamera(){
        ListenableFuture<ProcessCameraProvider> f=ProcessCameraProvider.getInstance(this);
        f.addListener(()->{try{provider=f.get();bindCamera();}catch(Exception e){toast("Kamera gagal dibuka");}},ContextCompat.getMainExecutor(this));
    }

    private void bindCamera(){
        if(provider==null)return; CameraSelector selector=front?CameraSelector.DEFAULT_FRONT_CAMERA:CameraSelector.DEFAULT_BACK_CAMERA;
        try{if(!provider.hasCamera(selector)){front=false;selector=CameraSelector.DEFAULT_BACK_CAMERA;}}
        catch(Exception ignored){}
        Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());
        imageCapture=new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).setFlashMode(flashMode).build();
        Recorder r=new Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD)).build();videoCapture=VideoCapture.withOutput(r);
        provider.unbindAll();camera=provider.bindToLifecycle(this,selector,p,imageCapture,videoCapture);
        camera.getCameraInfo().getZoomState().observe(this,z->{minZoom=z.getMinZoomRatio();maxZoom=z.getMaxZoomRatio();zoom=z.getZoomRatio();updateZoom();});
        status.setText("NINJACAM • "+mode);
    }

    private void selectMode(String m){
        if(recordingNow)return;mode=m;status.setText("NINJACAM • "+m);
        if(m.equals("ASTRO")||m.equals("PRO")) toast("Kontrol manual mengikuti kemampuan hardware Camera2.");
        if(m.equals("NIGHT")) {flashMode=ImageCapture.FLASH_MODE_OFF;toast("Night mode aktif • flash OFF");}
        if(m.equals("LIVE")) toast("Live Photo • foto + motion pendek");
        bindCamera();
    }

    private void shutter(){
        if(recordingNow){if(recording!=null)recording.stop();return;}
        if(mode.equals("VIDEO")){if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO);}else startVideoWithAudio(true);return;}
        if(mode.equals("LIVE")){takePhoto();handler.postDelayed(()->startShortLiveMotion(),450);return;}
        if(timerSeconds>0){shutter.setEnabled(false);handler.postDelayed(()->takePhoto(),timerSeconds*1000L);}else takePhoto();
    }

    private void takePhoto(){
        if(imageCapture==null)return; final String name="NinjaCam_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg";
        ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/NinjaCam");
        ImageCapture.OutputFileOptions o=new ImageCapture.OutputFileOptions.Builder(getContentResolver(),MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v).build();
        imageCapture.takePicture(o,ContextCompat.getMainExecutor(this),new ImageCapture.OnImageSavedCallback(){public void onImageSaved(@NonNull ImageCapture.OutputFileResults r){shutter.setEnabled(true);toast("Foto tersimpan • Pictures/NinjaCam");}public void onError(@NonNull ImageCaptureException e){shutter.setEnabled(true);toast("Gagal mengambil foto");}});
    }

    private void startVideoWithAudio(boolean audio){
        if(videoCapture==null||recordingNow)return;String name="NinjaCam_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";
        ContentValues v=new ContentValues();v.put(MediaStore.Video.Media.DISPLAY_NAME,name);v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");v.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/NinjaCam");
        MediaStoreOutputOptions o=new MediaStoreOutputOptions.Builder(getContentResolver(),MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(v).build();
        androidx.camera.video.PendingRecording pr=videoCapture.getOutput().prepareRecording(this,o);if(audio)pr=pr.withAudioEnabled();
        recording=pr.start(ContextCompat.getMainExecutor(this),e->{if(e instanceof VideoRecordEvent.Start){recordingNow=true;shutter.setText("■");status.setText("● REC • "+(audio?"AUDIO":"SILENT"));}else if(e instanceof VideoRecordEvent.Finalize){recordingNow=false;recording=null;shutter.setText("●");status.setText("NINJACAM • VIDEO");VideoRecordEvent.Finalize x=(VideoRecordEvent.Finalize)e;if(x.hasError())toast("Video gagal disimpan");else toast("Video tersimpan • Movies/NinjaCam");}});
    }

    private void startShortLiveMotion(){
        if(recordingNow||videoCapture==null)return;String name="NinjaCam_Live_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";ContentValues v=new ContentValues();v.put(MediaStore.Video.Media.DISPLAY_NAME,name);v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");v.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/NinjaCam");MediaStoreOutputOptions o=new MediaStoreOutputOptions.Builder(getContentResolver(),MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(v).build();recording=videoCapture.getOutput().prepareRecording(this,o).start(ContextCompat.getMainExecutor(this),e->{if(e instanceof VideoRecordEvent.Start){recordingNow=true;status.setText("LIVE • 2s");handler.postDelayed(()->{if(recording!=null)recording.stop();},2000);}else if(e instanceof VideoRecordEvent.Finalize){recordingNow=false;recording=null;status.setText("NINJACAM • LIVE");}});
    }

    private void switchCamera(){if(recordingNow)return;front=!front;bindCamera();}
    private void cycleFlash(){flashMode=flashMode==ImageCapture.FLASH_MODE_AUTO?ImageCapture.FLASH_MODE_ON:(flashMode==ImageCapture.FLASH_MODE_ON?ImageCapture.FLASH_MODE_OFF:ImageCapture.FLASH_MODE_AUTO);bindCamera();}
    private String flashLabel(){return flashMode==ImageCapture.FLASH_MODE_AUTO?"⚡ AUTO":(flashMode==ImageCapture.FLASH_MODE_ON?"⚡ ON":"⚡ OFF");}
    private void setZoom(float z){if(camera==null)return;zoom=Math.max(minZoom,Math.min(maxZoom,z));camera.getCameraControl().setZoomRatio(zoom);zoomText.setText(String.format(Locale.US,"%.1f×",zoom));}
    private void updateZoom(){if(zoomText==null)return;zoomText.setText(String.format(Locale.US,"%.1f×",zoom));float range=Math.max(.001f,maxZoom-minZoom);zoomSeek.setProgress((int)(((zoom-minZoom)/range)*1000));quickZoom.removeAllViews();float[] vals={.5f,1f,2f,5f,10f};for(float x:vals)if(x>=minZoom-.001f&&x<=maxZoom+.001f){Button b=glass(x%1==0?((int)x)+"×":x+"×");b.setOnClickListener(v->setZoom(x));quickZoom.addView(b);}}
    private void focus(float x,float y){if(camera==null)return;MeteringPointFactory f=preview.getMeteringPointFactory();FocusMeteringAction a=new FocusMeteringAction.Builder(f.createPoint(x,y)).setAutoCancelDuration(3,TimeUnit.SECONDS).build();camera.getCameraControl().startFocusAndMetering(a);}

    private void settings(){final String[] o={"Grid: "+(gridOn?"ON":"OFF"),"HDR: "+(hdrOn?"ON":"OFF"),"Preview: Glass UI","Gallery: NinjaCam folders"};new android.app.AlertDialog.Builder(this).setTitle("NinjaCam Settings").setItems(o,(d,w)->{if(w==0){gridOn=!gridOn;gridView.setVisibility(gridOn?View.VISIBLE:View.GONE);}else if(w==1)hdrOn=!hdrOn;else if(w==3)startActivity(new Intent(this,GalleryActivity.class));}).setNegativeButton("Tutup",null).show();}
    private Button glass(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setAllCaps(false);b.setPadding(dp(7),0,dp(7),0);b.setBackground(round(0xAA202020,dp(18),0x88FFFFFF));b.setOnClickListener(v->{v.animate().scaleX(.93f).scaleY(.93f).setDuration(60).withEndAction(()->v.animate().scaleX(1).scaleY(1).setDuration(90).start()).start();});return b;}
    private GradientDrawable round(int color,int radius,int stroke){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);if(stroke!=0)g.setStroke(dp(1),stroke);return g;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){if(recording!=null)recording.stop();if(provider!=null)provider.unbindAll();handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
