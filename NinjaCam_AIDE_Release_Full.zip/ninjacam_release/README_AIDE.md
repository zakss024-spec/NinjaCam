AIDE QUICK START

Extract → Open Project → pilih folder NinjaCam_AIDE_Release.

Jangan pilih folder .github karena project ini tidak membutuhkan GitHub Actions.

Untuk APK installable:
Build → assembleRelease

Output:
app/build/outputs/apk/release/app-release.apk
