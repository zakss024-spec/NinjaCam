# NinjaCam 0.7.0 — AIDE Release Project

Project native Android yang disiapkan untuk AIDE dengan Gradle 6.1.1 + Android Gradle Plugin 4.0.2.

## Build di AIDE
1. Extract ZIP.
2. AIDE → Open Project.
3. Pilih folder `NinjaCam_AIDE_Release`.
4. Tunggu Gradle sync selesai.
5. Build → `assembleRelease` atau Run.
6. APK release berada di `app/build/outputs/apk/release/app-release.apk`.

Release pada project ini ditandatangani memakai debug signing bawaan Gradle agar APK dapat langsung dipasang untuk testing. Untuk publikasi Play Store, buat signing key/release keystore milik developer dan ganti signingConfig.

## Fitur
- Intro video dari `app/src/main/assets/ninja_intro.mp4`, progress mengikuti durasi video, audio ikut diputar.
- Fullscreen camera preview.
- Foto ke `Pictures/NinjaCam`.
- Video + audio ke `Movies/NinjaCam`.
- NinjaCam Gallery untuk melihat foto hasil jepretan.
- Kamera depan/belakang.
- Pinch zoom + slider + quick zoom yang mengikuti kemampuan hardware.
- 0.5x hanya muncul jika camera API benar-benar melaporkan range tersebut.
- Flash Auto/On/Off.
- Timer 3/5 detik.
- Grid.
- HDR toggle UI.
- Night, Astro, Pro dan Live Photo mode sebagai workflow software/hardware-aware.
- Live Photo membuat foto lalu motion pendek 2 detik.
- Fokus dengan tap pada preview.
- Glass/dark UI dengan kontrol kamera yang sederhana.

## Catatan release
Project ini ditujukan untuk build AIDE/Android lama. Target SDK 30 dipilih agar kompatibel dengan AGP 4.0.2 + Gradle 6.1.1. Untuk Play Store modern, lakukan migrasi build tool ke AGP/Gradle terbaru dan naikkan target SDK sesuai persyaratan Google Play.
