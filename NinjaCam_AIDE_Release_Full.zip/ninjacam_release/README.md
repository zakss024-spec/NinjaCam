# NinjaCam 0.7.0

Native Android camera project with intro, photo/video capture, audio, zoom, modes and an in-app NinjaCam Gallery.

AIDE-ready build setup is included.
